import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

export function SkillsSection() {
  const technicalSkills = [
    { name: "HTML/CSS", percentage: 95 },
    { name: "JavaScript", percentage: 90 },
    { name: "React", percentage: 92 },
    { name: "Node.js", percentage: 85 },
    { name: "TypeScript", percentage: 88 },
    { name: "Next.js", percentage: 86 }
  ];

  const softwareSkills = [
    "Figma", "VS Code", "Git", "Docker", "AWS", "Firebase",
    "MongoDB", "PostgreSQL", "REST API", "GraphQL", "Tailwind CSS", 
    "Redux", "Jest", "Webpack", "Vercel", "Netlify"
  ];

  return (
    <section id="skills" className="py-16 md:py-24">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col items-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
            My <span className="bg-gradient-to-r from-blue-600 to-teal-500 bg-clip-text text-transparent">Skills</span>
          </h2>
          <div className="w-24 h-1.5 bg-gradient-to-r from-blue-600 to-teal-500 rounded-full"></div>
          <p className="mt-6 text-gray-600 dark:text-gray-300 text-center max-w-2xl">
            I've spent years refining my skills in web development. Here's a breakdown of my technical expertise and proficiency.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Technical Skills */}
          <div className="space-y-8">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white border-l-4 border-blue-500 dark:border-teal-500 pl-3">
              Technical Skills
            </h3>
            
            <div className="space-y-6">
              {technicalSkills.map((skill, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-gray-800 dark:text-gray-200">{skill.name}</span>
                    <span className="text-sm text-gray-500 dark:text-gray-400">{skill.percentage}%</span>
                  </div>
                  <Progress 
                    value={skill.percentage} 
                    className="h-2 bg-gray-200 dark:bg-gray-700"
                    indicatorClassName="bg-gradient-to-r from-blue-600 to-teal-500"
                  />
                </div>
              ))}
            </div>
          </div>
          
          {/* Software Skills */}
          <div className="space-y-8">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white border-l-4 border-blue-500 dark:border-teal-500 pl-3">
              Software & Tools
            </h3>
            
            <div className="flex flex-wrap gap-2">
              {softwareSkills.map((skill, index) => (
                <Badge 
                  key={index}
                  className="bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-800 dark:text-gray-200 py-2 px-3 rounded-md transition-colors"
                  variant="outline"
                >
                  {skill}
                </Badge>
              ))}
            </div>
            
            <div className="pt-4 space-y-4">
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white border-l-4 border-blue-500 dark:border-teal-500 pl-3">
                Services Offered
              </h3>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="flex items-start space-x-3">
                  <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-gray-800 flex items-center justify-center flex-shrink-0">
                    <div className="w-5 h-5 rounded-full bg-gradient-to-r from-blue-600 to-teal-500"></div>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900 dark:text-white">Website Development</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">Custom websites with modern technologies</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-gray-800 flex items-center justify-center flex-shrink-0">
                    <div className="w-5 h-5 rounded-full bg-gradient-to-r from-blue-600 to-teal-500"></div>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900 dark:text-white">UI/UX Design</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">Beautiful and intuitive user interfaces</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-gray-800 flex items-center justify-center flex-shrink-0">
                    <div className="w-5 h-5 rounded-full bg-gradient-to-r from-blue-600 to-teal-500"></div>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900 dark:text-white">API Development</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">Robust and scalable API solutions</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-gray-800 flex items-center justify-center flex-shrink-0">
                    <div className="w-5 h-5 rounded-full bg-gradient-to-r from-blue-600 to-teal-500"></div>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900 dark:text-white">Performance Optimization</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">Speed up your existing websites</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}