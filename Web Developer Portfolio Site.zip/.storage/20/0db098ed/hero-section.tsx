import { Button } from "@/components/ui/button";
import { ArrowDownCircle } from "lucide-react";

export function HeroSection() {
  const handleScroll = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      window.scrollTo({
        top: element.getBoundingClientRect().top + window.scrollY - 80,
        behavior: "smooth",
      });
    }
  };

  return (
    <section className="min-h-screen flex flex-col justify-center pt-16 pb-10 relative overflow-hidden" id="home">
      {/* Background gradient */}
      <div className="absolute -top-24 -left-24 w-96 h-96 bg-blue-500 rounded-full opacity-10 blur-3xl"></div>
      <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-teal-500 rounded-full opacity-10 blur-3xl"></div>
      
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="flex flex-col-reverse md:flex-row items-center gap-8 md:gap-12 lg:gap-16">
          <div className="w-full md:w-3/5 space-y-6 md:space-y-8 text-center md:text-left">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
              <span className="text-gray-900 dark:text-white">Hi, I'm </span>
              <span className="bg-gradient-to-r from-blue-600 to-teal-500 bg-clip-text text-transparent">John Doe</span>
            </h1>
            
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-semibold text-gray-700 dark:text-gray-300">
              Full Stack Web Developer
            </h2>
            
            <p className="text-base md:text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto md:mx-0">
              I create stunning web experiences with a focus on performance, accessibility, and beautiful design. With expertise in modern technologies, I bring ideas to life.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
              <Button 
                className="bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600 text-white px-8 py-6 h-auto text-lg"
                onClick={() => handleScroll("#projects")}
              >
                View My Work
              </Button>
              
              <Button 
                variant="outline" 
                className="border-2 border-gray-300 dark:border-gray-700 hover:border-blue-500 dark:hover:border-teal-500 px-8 py-6 h-auto text-lg"
                onClick={() => handleScroll("#contact")}
              >
                Contact Me
              </Button>
            </div>
          </div>
          
          <div className="w-full md:w-2/5 flex justify-center">
            <div className="relative w-64 h-64 md:w-80 md:h-80">
              <div className="absolute inset-0 rounded-full bg-gradient-to-br from-blue-500 to-teal-500 animate-pulse" style={{ animationDuration: '3s' }}></div>
              <img 
                src="/assets/profile.jpg" 
                alt="Profile Picture" 
                className="absolute inset-[3px] object-cover rounded-full border-4 border-white dark:border-gray-900"
              />
            </div>
          </div>
        </div>
        
        <div className="absolute bottom-12 left-1/2 transform -translate-x-1/2 animate-bounce hidden md:block">
          <button 
            onClick={() => handleScroll("#about")} 
            className="text-gray-400 hover:text-blue-500 dark:hover:text-teal-400 transition-colors"
          >
            <ArrowDownCircle size={32} />
            <span className="sr-only">Scroll down</span>
          </button>
        </div>
      </div>
    </section>
  );
}