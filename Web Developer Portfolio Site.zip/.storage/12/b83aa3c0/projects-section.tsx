import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Github, ExternalLink } from "lucide-react";

type Project = {
  id: number;
  title: string;
  description: string;
  image: string;
  category: string[];
  technologies: string[];
  demoLink: string;
  githubLink: string;
};

export function ProjectsSection() {
  const [activeFilter, setActiveFilter] = useState("all");

  const projects: Project[] = [
    {
      id: 1,
      title: "E-Commerce Platform",
      description: "A fully functional e-commerce platform with payment integration, user authentication, and admin dashboard.",
      image: "https://images.unsplash.com/photo-1556742502-ec7c0e9f34b1?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      category: ["web", "frontend", "backend"],
      technologies: ["React", "Node.js", "MongoDB", "Stripe"],
      demoLink: "#",
      githubLink: "#",
    },
    {
      id: 2,
      title: "Portfolio Website",
      description: "A responsive portfolio website template for creative professionals and developers.",
      image: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      category: ["web", "frontend"],
      technologies: ["React", "Tailwind CSS", "Framer Motion"],
      demoLink: "#",
      githubLink: "#",
    },
    {
      id: 3,
      title: "Task Management App",
      description: "A collaborative task management application with real-time updates and team functionality.",
      image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      category: ["web", "mobile"],
      technologies: ["React Native", "Firebase", "Redux"],
      demoLink: "#",
      githubLink: "#",
    },
    {
      id: 4,
      title: "Real Estate Listing",
      description: "A property listing website with advanced search, filtering, and map integration.",
      image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      category: ["web", "frontend"],
      technologies: ["Next.js", "Google Maps API", "Prisma"],
      demoLink: "#",
      githubLink: "#",
    },
    {
      id: 5,
      title: "Health Tracking Dashboard",
      description: "A comprehensive health metrics tracking dashboard with visualization and insights.",
      image: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      category: ["web", "frontend", "data"],
      technologies: ["Vue.js", "D3.js", "Express"],
      demoLink: "#",
      githubLink: "#",
    },
    {
      id: 6,
      title: "Social Media App",
      description: "A feature-rich social networking application with messaging and content sharing.",
      image: "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      category: ["mobile", "backend"],
      technologies: ["React Native", "GraphQL", "AWS"],
      demoLink: "#",
      githubLink: "#",
    },
  ];

  const categories = [
    { id: "all", label: "All" },
    { id: "web", label: "Web" },
    { id: "frontend", label: "Frontend" },
    { id: "backend", label: "Backend" },
    { id: "mobile", label: "Mobile" },
    { id: "data", label: "Data" },
  ];

  const filteredProjects = activeFilter === "all" 
    ? projects 
    : projects.filter(project => project.category.includes(activeFilter));

  return (
    <section id="projects" className="py-16 md:py-24 bg-gray-50 dark:bg-gray-900/50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col items-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
            Recent <span className="bg-gradient-to-r from-blue-600 to-teal-500 bg-clip-text text-transparent">Projects</span>
          </h2>
          <div className="w-24 h-1.5 bg-gradient-to-r from-blue-600 to-teal-500 rounded-full"></div>
          <p className="mt-6 text-gray-600 dark:text-gray-300 text-center max-w-2xl">
            Here are some of my recent works. I've worked on a wide range of projects, from web applications to mobile apps.
          </p>
        </div>

        <Tabs defaultValue="all" className="w-full">
          <TabsList className="flex flex-wrap justify-center mb-8 h-auto bg-transparent gap-2">
            {categories.map(category => (
              <TabsTrigger 
                key={category.id}
                value={category.id}
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-teal-500 data-[state=active]:text-white rounded-full px-6 py-2"
                onClick={() => setActiveFilter(category.id)}
              >
                {category.label}
              </TabsTrigger>
            ))}
          </TabsList>
          
          <TabsContent value={activeFilter} className="mt-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
              {filteredProjects.map(project => (
                <Card key={project.id} className="group overflow-hidden border-none shadow-lg hover:shadow-xl transition-shadow duration-300 bg-white dark:bg-gray-800">
                  <div className="relative overflow-hidden h-52">
                    <div className="absolute inset-0 bg-blue-600/20 dark:bg-teal-600/30 opacity-0 group-hover:opacity-100 transition-opacity z-10"></div>
                    <img 
                      src={project.image} 
                      alt={project.title} 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity z-20">
                      <Button 
                        variant="outline" 
                        size="icon" 
                        className="bg-white/90 dark:bg-gray-900/90 hover:bg-white dark:hover:bg-gray-900 rounded-full"
                        asChild
                      >
                        <a href={project.githubLink} target="_blank" rel="noopener noreferrer">
                          <Github className="h-4 w-4" />
                          <span className="sr-only">GitHub</span>
                        </a>
                      </Button>
                      <Button 
                        variant="outline" 
                        size="icon" 
                        className="bg-white/90 dark:bg-gray-900/90 hover:bg-white dark:hover:bg-gray-900 rounded-full"
                        asChild
                      >
                        <a href={project.demoLink} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4" />
                          <span className="sr-only">Live Demo</span>
                        </a>
                      </Button>
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <div className="flex flex-wrap gap-2 mb-3">
                      {project.technologies.map((tech, index) => (
                        <Badge 
                          key={index}
                          variant="outline" 
                          className="bg-gray-100 dark:bg-gray-700 border-none text-xs"
                        >
                          {tech}
                        </Badge>
                      ))}
                    </div>
                    <h3 className="font-semibold text-xl text-gray-900 dark:text-white mb-2">{project.title}</h3>
                    <p className="text-gray-600 dark:text-gray-300 text-sm">{project.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
        
        <div className="flex justify-center mt-12">
          <Button className="bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600 text-white px-8">
            View All Projects
          </Button>
        </div>
      </div>
    </section>
  );
}